                   Things that aren't done yet
                   ---------------------------

1. Implement PTHREAD_PROCESS_SHARED for semaphores, mutexes,
   condition variables, read/write locks, barriers.
   
   IMO, to do this in a source code compatible way requires implementation of
   POSIX shared memory functions, etc.
  